<?php
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "harsh1101";
$dbname = "electronics_orders";

// Establish connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Fetch all orders
$sql = "SELECT 
            order_id, 
            full_name, 
            email, 
            mobile, 
            CONCAT(area, ', ', landmark, ', ', residency) AS address, 
            product_id, 
            transaction_path, 
            upi_id, 
            status, 
            created_at 
        FROM orders";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $orders = [];
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
    echo json_encode(['success' => true, 'orders' => $orders]);
} else {
    echo json_encode(['success' => false, 'message' => 'No orders found.']);
}

// Close connection
$conn->close();
?>
