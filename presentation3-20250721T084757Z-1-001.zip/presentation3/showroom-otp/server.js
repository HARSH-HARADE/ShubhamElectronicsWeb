const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Replace with your email service credentials
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'garryvardhan0099@gmail.com',    // your Gmail address
        pass: 'g1a2r3r4y5',      // your Gmail password or app-specific password
    },
});

app.post('/send-email-otp', (req, res) => {
    const { email } = req.body;
    const otp = Math.floor(100000 + Math.random() * 900000);  // 6-digit OTP

    const mailOptions = {
        from: 'garryvardhan0099@gmail.com',
        to: email,
        subject: 'Your OTP Code',
        text: `Your OTP code is: ${otp}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error sending email:', error);
            res.status(500).json({ message: 'Failed to send OTP. Please try again.' });
        } else {
            console.log('Email sent:', info.response);
            res.json({ message: 'OTP sent successfully!' });
        }
    });
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
