<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

function sendEmailOTP($email) {
    $mail = new PHPMailer(true);

    try {
        // SMTP server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';  // Set the SMTP server to use
        $mail->SMTPAuth = true;
        $mail->Username = 'garryvardhan0099@gmail.com';  // Your email
        $mail->Password = 'g1a2r3r4y5';   // Your email password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // OTP Generation
        $otp = random_int(100000, 999999);

        // Email headers
        $mail->setFrom('garryvardhan0099@gmail.com', 'SHUBHAM ELECTRONICS');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Code';
        $mail->Body = "Your OTP code is: <b>$otp</b>";

        $mail->send();
        return 'OTP sent successfully!';
    } catch (Exception $e) {
        return 'Error: OTP could not be sent.';
    }
}

// Handle the request from the frontend
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $data = json_decode(file_get_contents("php://input"), true);
    $email = $data['email'] ?? '';

    if (!empty($email)) {
        $responseMessage = sendEmailOTP($email);
        echo json_encode(['message' => $responseMessage]);
    } else {
        echo json_encode(['message' => 'Please provide an email address.']);
    }
}
?>
