<?php
// Database connection
$servername = "localhost";  // Your database server (localhost if running locally)
$username = "root";         // Your database username (root for XAMPP default)
$password = "harsh1101";             // Your database password (empty for XAMPP default)
$dbname = "electronics_orders"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the email from POST request
$email = $_POST['email'];

// Query to fetch the order status for the provided email
$sql = "SELECT order_id, product_id, status FROM orders WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// Check if orders are found
if ($result->num_rows > 0) {
    echo "<div class='order-status'>";
    echo "<h2>Order Status for Email: $email</h2>";
    while ($row = $result->fetch_assoc()) {
        echo "<div class='order-item'>";
        echo "<p><strong>Order ID:</strong> " . $row['order_id'] . "</p>";
        echo "<p><strong>Product ID:</strong> " . $row['product_id'] . "</p>";
        echo "<p><strong>Status:</strong> " . $row['status'] . "</p>";
        echo "</div>";
    }
    echo "</div>";
} else {
    // No orders found
    header('Location: index.html?status=no_results');
    exit();
}

// Close the connection
$stmt->close();
$conn->close();
?>
