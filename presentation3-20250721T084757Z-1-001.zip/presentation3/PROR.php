<?php
// Include database connection
include('db_connection.php');

// Check if the order_id is set in the URL
if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];

    // Query to fetch the order details
    $query = "SELECT * FROM orders WHERE order_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // If the order is found
    if ($result->num_rows > 0) {
        $order = $result->fetch_assoc();
    } else {
        die('Order not found.');
    }
} else {
    die('Order ID is missing.');
}

// Fetch the order details
$order_id = $order['order_id'];
$full_name = $order['full_name'];
$email = $order['email'];
$mobile = $order['mobile'];
$address = $order['address'];
$product_id = $order['product_id'];
$transaction_path = $order['transaction_path'];
$upi_id = $order['upi_id'];
$status = $order['status'];
$created_at = $order['created_at'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt - Order #<?php echo $order_id; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .receipt-container {
            width: 80%;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .receipt-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .receipt-header h1 {
            margin: 0;
            color: #4caf50;
        }
        .receipt-header p {
            font-size: 1.1em;
            color: #333;
        }
        .receipt-details {
            margin-top: 20px;
        }
        .receipt-details th, .receipt-details td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .receipt-details th {
            background-color: #4caf50;
            color: white;
        }
        .btn {
            padding: 10px 15px;
            background-color: #4caf50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px;
        }
        .btn:hover {
            background-color: #45a049;
        }
        @media print {
            body {
                margin: 0;
                padding: 0;
            }
            .btn {
                display: none;
            }
        }
    </style>
</head>
<body>

    <div class="receipt-container">
        <div class="receipt-header">
            <h1>Receipt for Order #<?php echo $order_id; ?></h1>
            <p>Shubham Electronics</p>
        </div>

        <table class="receipt-details">
            <tr>
                <th>Order ID</th>
                <td><?php echo $order_id; ?></td>
            </tr>
            <tr>
                <th>Full Name</th>
                <td><?php echo $full_name; ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo $email; ?></td>
            </tr>
            <tr>
                <th>Mobile</th>
                <td><?php echo $mobile; ?></td>
            </tr>
            <tr>
                <th>Address</th>
                <td><?php echo $address; ?></td>
            </tr>
            <tr>
                <th>Product ID</th>
                <td><?php echo $product_id; ?></td>
            </tr>
            <tr>
                <th>Transaction Path</th>
                <td><?php echo $transaction_path; ?></td>
            </tr>
            <tr>
                <th>UPI ID</th>
                <td><?php echo $upi_id; ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <td><?php echo $status; ?></td>
            </tr>
            <tr>
                <th>Created At</th>
                <td><?php echo $created_at; ?></td>
            </tr>
        </table>

        <button class="btn" onclick="window.print()">Print Receipt</button>
    </div>

</body>
</html>

<?php
// Close the database connection
$stmt->close();
$conn->close();
?>
