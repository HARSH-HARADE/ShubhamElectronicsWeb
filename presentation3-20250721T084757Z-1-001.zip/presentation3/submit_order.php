<?php
// Database connection settings
$servername = "localhost"; // Change if MySQL is running on a different host
$username = "root";        // Replace with your MySQL username
$password = "harsh1101";            // Replace with your MySQL password
$dbname = "electronics_orders"; // Your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data from the form
    $fullName = $_POST['fullName'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $area = $_POST['area'];
    $landmark = $_POST['landmark'];
    $residency = $_POST['residency'];
    $productId = $_POST['productId'];
    
    // Handle file upload
    $transactionPath = '';
    if (isset($_FILES['transactionScreenshot']) && $_FILES['transactionScreenshot']['error'] == 0) {
        $target_dir = "uploads/"; // Make sure this directory exists and is writable
        $transactionPath = $target_dir . basename($_FILES["transactionScreenshot"]["name"]);
        move_uploaded_file($_FILES["transactionScreenshot"]["tmp_name"], $transactionPath);
    }

    // Insert data into the database
    $sql = "INSERT INTO orders (full_name, email, mobile, area, landmark, residency, product_id, transaction_path)
            VALUES ('$fullName', '$email', '$mobile', '$area', '$landmark', '$residency', '$productId', '$transactionPath')";

    if ($conn->query($sql) === TRUE) {
        echo "Order submitted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
