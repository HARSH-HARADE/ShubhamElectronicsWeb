<?php
header('Content-Type: application/json');

// Database connection details
$servername = "localhost";
$username = "root";
$password = "harsh1101";
$dbname = "electronics_orders";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check database connection
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Get JSON input data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['service_id'], $data['status'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid input data.']);
    exit();
}

$service_id = $data['service_id'];
$status = $data['status'];

// Validate status value
$valid_statuses = ['Approved', 'Rejected', 'Cancelled', 'Pending'];
if (!in_array($status, $valid_statuses)) {
    echo json_encode(['success' => false, 'message' => 'Invalid status value.']);
    exit();
}

// Update the status in the database
$sql = "UPDATE repair_orders SET status = ? WHERE service_id = ?"; // Corrected SQL query

// Prepare statement
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Prepare failed: ' . $conn->error]);
    exit();
}

// Bind parameters and execute query
$stmt->bind_param("si", $status, $service_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Status updated successfully.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Execute failed: ' . $stmt->error]);
}

// Close connections
$stmt->close();
$conn->close();
?>
