<?php
// Get the data from the URL query string
$service_id = isset($_GET['service_id']) ? $_GET['service_id'] : '';
$full_name = isset($_GET['full_name']) ? $_GET['full_name'] : '';
$email = isset($_GET['email']) ? $_GET['email'] : '';
$mobile = isset($_GET['mobile']) ? $_GET['mobile'] : '';
$repair_date = isset($_GET['repair_date']) ? $_GET['repair_date'] : '';
$repair_time = isset($_GET['repair_time']) ? $_GET['repair_time'] : '';
$service_type = isset($_GET['service_type']) ? $_GET['service_type'] : '';
$area = isset($_GET['area']) ? $_GET['area'] : '';
$landmark = isset($_GET['landmark']) ? $_GET['landmark'] : '';
$residency = isset($_GET['residency']) ? $_GET['residency'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';

// Generate the receipt HTML
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        .receipt {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            background: #f9f9f9;
        }
        .receipt h2 {
            text-align: center;
            color: #4caf50;
        }
        .receipt-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .receipt-table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background: #4caf50;
            color: white;
        }
    </style>
</head>
<body>

    <div class="receipt">
        <h2>Repair Order Receipt</h2>
        <table class="receipt-table">
            <tr>
                <th>Order ID</th>
                <td><?php echo htmlspecialchars($service_id); ?></td>
            </tr>
            <tr>
                <th>Full Name</th>
                <td><?php echo htmlspecialchars($full_name); ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo htmlspecialchars($email); ?></td>
            </tr>
            <tr>
                <th>Mobile</th>
                <td><?php echo htmlspecialchars($mobile); ?></td>
            </tr>
            <tr>
                <th>Repair Date</th>
                <td><?php echo htmlspecialchars($repair_date); ?></td>
            </tr>
            <tr>
                <th>Repair Time</th>
                <td><?php echo htmlspecialchars($repair_time); ?></td>
            </tr>
            <tr>
                <th>Service Type</th>
                <td><?php echo htmlspecialchars($service_type); ?></td>
            </tr>
            <tr>
                <th>Area</th>
                <td><?php echo htmlspecialchars($area); ?></td>
            </tr>
            <tr>
                <th>Landmark</th>
                <td><?php echo htmlspecialchars($landmark); ?></td>
            </tr>
            <tr>
                <th>Residency</th>
                <td><?php echo htmlspecialchars($residency); ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <td><?php echo htmlspecialchars($status); ?></td>
            </tr>
        </table>
        <div style="text-align: center; margin-top: 20px;">
            <button onclick="window.print()">Print Receipt</button>
        </div>
    </div>

</body>
</html>
