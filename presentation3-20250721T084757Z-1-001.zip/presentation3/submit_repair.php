<?php
header('Content-Type: application/json');

// Database connection details
$servername = "localhost";
$username = "root";
$password = "harsh1101";
$dbname = "electronics_orders";

// Establish a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check database connection
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Handle JSON or POST requests
$data = json_decode(file_get_contents('php://input'), true) ?: $_POST;

// Collect and sanitize data
$full_name = $data['fullName'] ?? null;
$email = $data['email'] ?? null;
$mobile = $data['mobile'] ?? null;
$repair_date = $data['repairDate'] ?? null;
$repair_time = $data['repairTime'] ?? null;
$service_type = $data['serviceType'] ?? null;
$area = $data['area'] ?? null;
$landmark = $data['landmark'] ?? null;
$residency = $data['residency'] ?? null;

// Validate required fields
if (empty($full_name) || empty($email) || empty($mobile) || empty($repair_date) || empty($repair_time) || empty($service_type)) {
    echo json_encode(['success' => false, 'message' => 'Please fill out all required fields.']);
    exit();
}

if ($service_type === 'home' && (empty($area) || empty($landmark) || empty($residency))) {
    echo json_encode(['success' => false, 'message' => 'Please provide all details for home service.']);
    exit();
}

// Prepare SQL query
$sql = "INSERT INTO repair_orders (
            full_name, email, mobile, repair_date, repair_time, service_type, 
            area, landmark, residency
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Error preparing SQL statement: ' . $conn->error]);
    exit();
}

// Bind parameters and execute
$stmt->bind_param(
    "sssssssss",
    $full_name, $email, $mobile, $repair_date, $repair_time, $service_type,
    $area, $landmark, $residency
);

if ($stmt->execute()) {
    $last_id = $conn->insert_id; // Get the auto-generated service ID
    echo json_encode(['success' => true, 'message' => 'Repair scheduled successfully!', 'serviceId' => str_pad($last_id, 6, '0', STR_PAD_LEFT)]);
} else {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $stmt->error]);
}

// Close connections
$stmt->close();
$conn->close();
?>
