<?php
echo "PHP Server is working!";
?>
