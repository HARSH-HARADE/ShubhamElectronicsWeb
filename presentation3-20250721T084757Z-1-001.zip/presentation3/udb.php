<?php
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "harsh1101";
$dbname = "electronics_orders";

// Establish connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Get the data from the request
$data = json_decode(file_get_contents('php://input'), true);
$order_id = $data['order_id'] ?? null;
$upi_id = $data['upi_id'] ?? null;

// Validate input data
if (!$order_id || !$upi_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid input: Missing order ID or UPI ID.']);
    exit();
}

// Check if the order exists and validate its current status
$check_sql = "SELECT status, upi_id FROM orders WHERE order_id = ?";
$check_stmt = $conn->prepare($check_sql);

if (!$check_stmt) {
    echo json_encode(['success' => false, 'message' => 'Statement preparation failed: ' . $conn->error]);
    exit();
}

$check_stmt->bind_param("i", $order_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows > 0) {
    $row = $check_result->fetch_assoc();

    // Prevent duplicate requests with the same UPI ID
    if ($row['status'] === 'Pending' && $row['upi_id'] === $upi_id) {
        echo json_encode(['success' => false, 'message' => 'Duplicate request: UPI ID is already pending for cancellation.']);
        exit();
    }

    // Prevent cancellation of orders that are already cancelled
    if ($row['status'] === 'Cancelled') {
        echo json_encode(['success' => false, 'message' => 'Order is already cancelled.']);
        exit();
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Order ID not found.']);
    exit();
}

// Update the status to "Pending" and store the UPI ID
$update_sql = "UPDATE orders SET status = 'Pending', upi_id = ? WHERE order_id = ?";
$update_stmt = $conn->prepare($update_sql);

if (!$update_stmt) {
    echo json_encode(['success' => false, 'message' => 'Statement preparation failed: ' . $conn->error]);
    exit();
}

$update_stmt->bind_param("si", $upi_id, $order_id);

if ($update_stmt->execute()) {
    if ($update_stmt->affected_rows > 0) {
        echo json_encode(['success' => true, 'message' => 'Order cancellation request submitted successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'No order found with the provided Order ID.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Execution failed: ' . $update_stmt->error]);
}

// Close the statements and connection
$check_stmt->close();
$update_stmt->close();
$conn->close();
?>
